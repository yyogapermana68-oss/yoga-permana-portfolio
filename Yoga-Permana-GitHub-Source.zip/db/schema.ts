// Intentionally empty by default.
// Add Drizzle tables here when the site actually needs a database.
// See examples/d1/db/schema.ts for an opt-in example.
import {sqliteTable,text} from 'drizzle-orm/sqlite-core';
export const portfolio=sqliteTable('portfolio',{id:text('id').primaryKey(),content:text('content').notNull(),updated:text('updated').notNull()});
export const media=sqliteTable('media',{id:text('id').primaryKey(),name:text('name').notNull(),type:text('type').notNull(),created:text('created').notNull()});
