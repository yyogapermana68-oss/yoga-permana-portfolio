
import Portfolio from './portfolio';
import { readContent, publicContent } from './store';
export const dynamic = 'force-dynamic';
export async function generateMetadata(){const d=await readContent();return {title:d.seoTitle,description:d.seoDescription,alternates:{canonical:'https://yoga-permana-portfolio.yyogapermana68.chatgpt.site'},openGraph:{title:d.seoTitle,description:d.seoDescription,type:'website'},twitter:{card:'summary',title:d.seoTitle,description:d.seoDescription}}}
export default async function Home(){return <Portfolio data={publicContent(await readContent())}/>;}
