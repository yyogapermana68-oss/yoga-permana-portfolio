import type { Metadata } from "next";
import "./globals.css";
import "./motion.css";

export const metadata: Metadata = {
  title: "Yoga Permana — Brands. Ideas. Impact.",
  description: "Strategy, creativity, performance and business growth. The portfolio of Yoga Permana.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
