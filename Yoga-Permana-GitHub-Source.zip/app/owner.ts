import {env} from 'cloudflare:workers';
import {getChatGPTUser} from './chatgpt-auth';
export async function isOwner(){const user=await getChatGPTUser();const email=(env as any).OWNER_EMAIL;return !!user&&!!email&&user.email.toLowerCase()===email.toLowerCase()}
export function sameOrigin(r:Request){return r.headers.get('origin')===new URL(r.url).origin}
