'use client';
export default function ErrorPage({reset}:{reset:()=>void}){return <main className="section"><h2>Temporarily unavailable.</h2><p className="admin-notice">The portfolio could not load. Please try again.</p><button className="outline-button" onClick={reset}>Try again</button></main>}
