export default function NotFound(){return <main className="section"><span className="eyebrow">404</span><h2>Project not found.</h2><a className="text-link" href="/">Back to portfolio</a></main>}
