import {readContent,publicContent} from './store';
export const dynamic='force-dynamic';
export default async function sitemap(){const base='https://yoga-permana-portfolio.yyogapermana68.chatgpt.site';const d=publicContent(await readContent());return [{url:base},...d.projects.map(p=>({url:base+'/work/'+p.slug}))]}
