export default function robots(){return {rules:{userAgent:'*',allow:'/',disallow:['/admin','/api']},sitemap:'https://yoga-permana-portfolio.yyogapermana68.chatgpt.site/sitemap.xml'}}
