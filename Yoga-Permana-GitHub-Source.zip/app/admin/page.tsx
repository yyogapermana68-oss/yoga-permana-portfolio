import {requireChatGPTUser} from '../chatgpt-auth';
import {isOwner} from '../owner';
import {readContent} from '../store';
import Editor from './editor';
export const dynamic='force-dynamic';
export const metadata={title:'Owner dashboard — Yoga Permana',robots:{index:false,follow:false}};
export default async function Admin(){await requireChatGPTUser('/admin');if(!await isOwner())return <main className="section"><span className="eyebrow">Owner dashboard</span><h2>Access restricted.</h2><p className="admin-notice">Your signed-in email must match the configured portfolio owner.</p><a className="text-link" href="/">Back to portfolio</a></main>;return <Editor initial={await readContent(true)}/>}
