'use client';

import {useEffect,useRef,useState,type ReactNode} from 'react';

const ease='cubic-bezier(.22,1,.36,1)';

/** Only unambiguous decimals animate; locale-formatted values retain their exact text. */
export function parseMetric(value:string){
 const match=value.match(/^(\s*)([+-]?\d+(?:\.\d{1,2})?)(\s*(?:%|[KMBT])?\+?\s*)$/i);
 if(!match)return null;
 const number=Number(match[2]);
 if(!Number.isFinite(number)||Math.abs(number)>1e12)return null;
 return {number,precision:match[2].split('.')[1]?.length||0,prefix:match[1]+(match[2].startsWith('+')?'+':''),suffix:match[3]};
}

export function MetricValue({value}:{value:string}){
 const el=useRef<HTMLSpanElement>(null);
 useEffect(()=>{
  const node=el.current,parsed=parseMetric(value),media=matchMedia('(prefers-reduced-motion: reduce)');
  if(!node||!parsed||media.matches||!('IntersectionObserver' in window))return;
  let frame=0;
  const reset=()=>{cancelAnimationFrame(frame);node.textContent=value};
  const observer=new IntersectionObserver(entries=>{
   if(!entries.some(e=>e.isIntersecting))return;
   observer.disconnect();const start=performance.now();
   const tick=(now:number)=>{if(media.matches){reset();return}const t=Math.min(1,(now-start)/1100);node.textContent=t===1?value:parsed.prefix+(parsed.number*(1-Math.pow(1-t,4))).toFixed(parsed.precision)+parsed.suffix;if(t<1)frame=requestAnimationFrame(tick)};
   frame=requestAnimationFrame(tick);
  },{threshold:.4});
  observer.observe(node);media.addEventListener('change',reset);
  return()=>{observer.disconnect();media.removeEventListener('change',reset);reset()};
 },[value]);
 return <strong aria-label={value}><span aria-hidden="true" ref={el}>{value}</span></strong>;
}

export function MotionScope({children,preview=false,refreshKey=''}:{children:ReactNode;preview?:boolean;refreshKey?:string}){
 const root=useRef<HTMLDivElement>(null);
 const [intro,setIntro]=useState(false);
 useEffect(()=>{
  if(preview||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  try{if(sessionStorage.getItem('yp-intro'))return;sessionStorage.setItem('yp-intro','1')}catch{return}
  setIntro(true);const timer=setTimeout(()=>setIntro(false),850);return()=>clearTimeout(timer);
 },[preview]);
 useEffect(()=>{
  const scope=root.current;if(!scope||preview)return;
  const media=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover: hover) and (pointer: fine)');
  let teardown=()=>{};
  const setup=()=>{
   teardown();
   if(media.matches){setIntro(false);scope.classList.remove('motion-active');return}
   scope.classList.add('motion-active');
   const animations=new Set<Animation>();let frame=0;
   const play=(el:HTMLElement,frames:Keyframe[],options:KeyframeAnimationOptions)=>{
    const animation=el.animate(frames,options);animations.add(animation);animation.onfinish=()=>{animations.delete(animation);animation.cancel()};
   };
   const items=scope.querySelectorAll<HTMLElement>('.section-top,.section-heading,h2,.empty-work,.project,.metrics>div,.brands>div,.featured>div,.featured>img,.process>div,.timeline>article,.experience-note,.footer-top,.footer-content>p,.footer-content>button');
   const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{
    if(!entry.isIntersecting)return;const el=entry.target as HTMLElement;observer.unobserve(el);
    if(el.dataset.revealed==='true')return;el.dataset.revealed='true';
    const i=Number(el.dataset.stagger||0);
    play(el,el.matches('.featured>img')?[{opacity:0,clipPath:'polygon(0 0,0 0,0 100%,0 100%)',transform:'scale(1.04)'},{opacity:1,clipPath:'polygon(0 0,100% 0,100% 100%,0 100%)',transform:'scale(1)'}]:[{opacity:0,transform:'translateY(22px)'},{opacity:1,transform:'translateY(0)'}],{duration:760,delay:Math.min(i,5)*75,easing:ease,fill:'backwards'});
   }),{threshold:.12,rootMargin:'0px 0px -24px 0px'});
   items.forEach(el=>observer.observe(el));
   const hero=scope.querySelector<HTMLElement>('.hero'),nav=scope.querySelector<HTMLElement>('.nav');
   const portrait=scope.querySelector<HTMLElement>('.portrait>img'),type=scope.querySelector<HTMLElement>('.hero-type');
   const panels=Array.from(scope.querySelectorAll<HTMLElement>('.hero-collage a'));
   const process=scope.querySelector<HTMLElement>('.process'),timeline=scope.querySelector<HTMLElement>('.timeline');
   const parallax=()=>{
    frame=0;const height=window.innerHeight;
    nav?.classList.toggle('is-scrolled',window.scrollY>80);
    if(!fine.matches||window.innerWidth<=900)[portrait,type,...panels].forEach(el=>{if(el)el.style.translate=''});
    if(hero){const rect=hero.getBoundingClientRect();if(rect.bottom>0&&rect.top<height){const progress=Math.max(0,Math.min(400,height*.4,-rect.top));if(fine.matches&&window.innerWidth>900){if(portrait)portrait.style.translate=`0 ${progress*.12}px`;if(type)type.style.translate=`0 ${progress*.025}px`;panels.forEach((p,i)=>p.style.translate=`0 ${progress*(i%2?.06:-.045)}px`)}}}
    [process,timeline].forEach(el=>{if(!el)return;const rect=el.getBoundingClientRect();const progress=Math.max(0,Math.min(1,(height*.82-rect.top)/(Math.min(rect.height,height*.7)+height*.15)));el.style.setProperty('--line-progress',String(progress));Array.from(el.children).forEach((child,i)=>child.classList.toggle('step-active',progress>i/Math.max(1,el.children.length)))});
   };
   const queue=()=>{if(!frame)frame=requestAnimationFrame(parallax)};
   const magnet=(e:PointerEvent)=>{if(!fine.matches)return;const target=(e.target as Element).closest<HTMLElement>('[data-magnetic]');if(!target||!scope.contains(target))return;const r=target.getBoundingClientRect();target.style.setProperty('--mx',`${Math.max(-6,Math.min(6,(e.clientX-r.left-r.width/2)*.1))}px`);target.style.setProperty('--my',`${Math.max(-6,Math.min(6,(e.clientY-r.top-r.height/2)*.1))}px`)};
   const release=(e:PointerEvent)=>{const target=(e.target as Element).closest<HTMLElement>('[data-magnetic]');if(target&&!target.contains(e.relatedTarget as Node)){target.style.setProperty('--mx','0px');target.style.setProperty('--my','0px')}};
   window.addEventListener('scroll',queue,{passive:true});window.addEventListener('resize',queue,{passive:true});scope.addEventListener('pointermove',magnet,{passive:true});scope.addEventListener('pointerout',release,{passive:true});queue();
   teardown=()=>{observer.disconnect();animations.forEach(a=>a.cancel());cancelAnimationFrame(frame);window.removeEventListener('scroll',queue);window.removeEventListener('resize',queue);scope.removeEventListener('pointermove',magnet);scope.removeEventListener('pointerout',release);[portrait,type,...panels].forEach(el=>{if(el)el.style.translate=''});[process,timeline].forEach(el=>el?.style.removeProperty('--line-progress'));scope.querySelectorAll<HTMLElement>('[data-magnetic]').forEach(el=>{el.style.removeProperty('--mx');el.style.removeProperty('--my')})};
  };
  setup();media.addEventListener('change',setup);return()=>{teardown();media.removeEventListener('change',setup)};
 },[preview,refreshKey]);
 return <div ref={root} className="portfolio-motion">{intro&&<div className="intro-mark" aria-hidden="true"><span>YP<span className="copper"> /</span></span><i/></div>}{children}</div>;
}

